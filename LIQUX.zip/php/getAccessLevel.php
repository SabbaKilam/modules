<?php

    session_start();    
    exit( $_SESSION["accessLevel"] );

?>