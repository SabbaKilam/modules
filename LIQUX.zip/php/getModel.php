<?php
    exit(file_get_contents("../model.json"));
?>