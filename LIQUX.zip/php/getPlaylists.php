<?php
    //exit the script with the json file to hand it to our javascript
    exit(file_get_contents("../playlists/playlists.json"));
?>