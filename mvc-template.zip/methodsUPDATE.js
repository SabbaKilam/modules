/*global L*/
/*global m*/
/*global v*/
/*global c*/
/////////////////////////

c.updateModel = (eventObject)=>{
  //first, update meta events:
  c.updateMetaEvents(eventObject)  
  //now list the possible "handlers", based on event info:
  const functionQualifiers = {
    setRandomColor: [m.doublePressed, m.source === v.app],
    setFooterActive:[m.clicked, m.source === v.footerGlass ]
  }
  //now run the functions that qualify:
  L.runQualifiedFunctions(functionQualifiers, m, v, c)
  
  //now update the view for non event-dependent view updates
  c.updateView()
}
//--------------------------//
c.updateView = () => {
  c.displayEventInfo(v);
}
//////////////////////////////////

c.updateMetaEvents = (eventObject)=>{
  /*
    meta events are transient states
    related to the current event
  */  
  const currentTime = Date.now()  
  m.elapsedTime = currentTime - m.startTime
  m.startTime = currentTime
  m.historyElapsedTime.unshift(m.elapsedTime)
  m.historyElapsedTime.pop()
  
  m.eventObject = eventObject
  m.source = m.eventObject.target
  
  m.id = m.source.id
  m.historyId.unshift(m.id)
  m.historyId.pop()
  
  //save current and prior two event types
  m.type = m.eventObject.type
  m.historyType.unshift(m.type)
  m.historyType.pop() 
  
  m.pressed = m.type === `mousedown` ||
              m.type === `touchstart`
  m.historyPressed.unshift(m.pressed)
  m.historyPressed.pop()
  
  m.released = m.type === `mouseup` ||
              m.type === `touchend` 
  m.historyReleased.unshift(m.released)
  m.historyReleased.pop()
  
  m.moved = m.type === `mousemove` ||
            m.type === `touchmove`
  m.historyMoved.unshift(m.moved)
  m.historyMoved.pop()
  
  //keep count of consequtive mousemoves or touchmoves
  m.moved && m.historyMoved[1]
    ? m.moveCount++
    : m.moveCount = 0

  m.clicked = m.elapsedTime <= m.MAX_TIME &&
              m.elapsedTime >= m.MIN_TIME &&
              m.released
  
  
  //two releases in quick succession  
  m.doublePressed = m.historyReleased[0] &&
                    m.historyPressed[1] &&
                    m.historyReleased[2] &&
                    m.historyPressed[3]  &&
                    m.historyElapsedTime[1] <= 250 &&
                    m.historyElapsedTime[1] > 25
}
//////////////////////////////////
