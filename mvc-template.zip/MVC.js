/*global L*/
const m = {} //MODEL
const v = {} //VIEW
const c = {} //CONTROLLER
/////////////////////////

c.initialize = (eventObject)=>{
  c.defineStateVariables(m)
  // when app loads, this is the first start time    
  m.startTime = Date.now() 
  
  window.id = "window"
  document.id = "document"
  L.attachAllElementsById(v)

  c.updateMetaEvents(eventObject)
  
  const eventTypes = [
    "mousedown",
    "touchstart",
    "mouseup",
    "touchend",  
    "resize",
    "load",
    "DOMContentLoaded",      
    "change",
    "input",
    "mouseover",
    "mouseout",
    "mousemove",
    "touchmove",
    "online",
    "offline",
    "keyup",
    "keydown",    
  ]
  
  for(let eventType of eventTypes){
    window.addEventListener(eventType, c.updateModel, true)
  }
  
  L.noPinchZoom()
  
  //call updateView repeatedly for non-event triggered model updates
  //L.loopCall(c.updateView, 16.66667, v) //16.66667 milliseconds = 60 frames / sec
}
///////////////////////////////////
