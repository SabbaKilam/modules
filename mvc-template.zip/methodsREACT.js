/*global L*/
/*global m*/
/*global v*/
/*global c*/
////////////////////////////

c.setRandomColor = (m) => {
  m.hue = Math.round(360 * Math.random())
  const saturation = Math.round(100 * Math.random())
  const lightness = Math.round(100 * Math.random())  
  m.randomColor = `hsl(${m.hue}, ${saturation}%, ${lightness}%)`
}
c.showRandomColor = ({app}) => {
  const complementHue = Math.abs(180 - m.hue)
  app
    .styles
      (`background-color: ${m.randomColor}`)
      (`color: hsl(${complementHue}, 85%, 50%)`)
  
}
///////////////////////////////////
c.setFooterActive = (m)=>{
  m.footerActive = !m.footerActive
}
c.showFooterActive = ({app})=>{
  v.app.innerText = `Footer active: ${m.footerActive.toString().toUpperCase()}`
  
  m.footerActive
   ? v.footerGlass.styles(`background: linear-gradient(-20deg, transparent, pink, transparent, pink, transparent)`)
   : v.footerGlass.styles(`background: transparent`)  
}
///////////////////////////////