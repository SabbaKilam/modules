/*global L*/
/*global m*/
/*global v*/
/*global c*/
//////////////////////////////////////////
c.defineStateVariables = (m)=>{
  // Define these meta events for the MODEL of any app
  m.startTime = Date.now() //best done in initialize

  m.eventObject = {type:`none`, target: {id: `none`}}
  m.source = m.eventObject.target
  m.type = m.eventObject.type
  //save current and prior two event types, four deep (or as deep as you like)
  m.historyType = [``,``,``,``]
  m.historyType.unshift(m.type)
  m.historyType.pop()

  m.historyId = [``,``,``,``]
  m.id = m.source.id //we could keep a history of ids as well
  m.historyId.unshift(m.id)
  m.historyId.pop()

  m.historyPressed = [false, false, false, false]
  m.pressed = m.type === `mousedown` ||
              m.type === `touchstart`
  m.historyPressed.unshift(m.pressed)
  m.historyPressed.pop()

  m.historyReleased = [false, false, false, false]
  m.released = m.type === `mouseup` ||
               m.type === `touchend`
  m.historyReleased.unshift(m.released)
  m.historyReleased.pop()

  m.historyMoved = [false, false, false, false]
  m.moved = m.type === `mousemove` ||
            m.type === `touchmove`
  m.historyMoved.unshift(m.moved)
  m.historyMoved.pop()

  m.elapsedTime = Date.now() - m.startTime
  m.historyElapsedTime = [0,0,0,0]
  m.historyElapsedTime.unshift(m.elapsedTime)
  m.historyElapsedTime.pop()

  m.clicked = m.elapsedTime <= m.MAX_TIME &&
              m.elapsedTime >= m.MIN_TIME &&
              m.released

  //two releases in quick succession  
  m.doublePressed = m.historyReleased[0] &&
                    m.historyPressed[1] &&
                    m.historyReleased[2] &&
                    m.historyPressed[3]  &&
                    m.historyElapsedTime[1] <= 250 &&
                    m.historyElapsedTime[1] > 25

  m.footerActive = false;

  /////////////////////| state variables for this particular app |//////////////
  m.MIN_TIME = 25 //milliseconds
  m.MAX_TIME = 750 //milliseconds

  m.randomColor = `hsl(0, 90%, 50%)`
  m.eventMessage = `${m.id}: ${m.type}, prior id: ${m.historyId[1]}`
  m.moveCount = 0;
}
//--------------------------//
c.displayEventInfo = ({footerInfo})=>{
  c.eventMessage = `${m.id}: ${m.type}, prior: ${m.historyType[1]}, moves: ${m.moveCount}`
  footerInfo.innerText = c.eventMessage 
}