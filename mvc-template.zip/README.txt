An opinionated MVC architecture that uses my L.js library

