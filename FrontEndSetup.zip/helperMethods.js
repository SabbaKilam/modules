/*global L*/
/*global m*/
/*global v*/
/*global c*/

//====================| HELPER methods |=========================//
c.restorePriorModel = function(eventObject){
  if(localStorage && localStorage.getItem('m')){
    m = JSON.parse(localStorage.getItem('m'))// Use it, then ...
    localStorage.removeItem('m') // ... lose it.
    console.log('locally stored m:', localStorage.getItem('m'))
  }  
  Object.keys(m.modelMethodQualifiers).forEach(methodName =>{
    m.isOnline = navigator.onLine  
    let prefix = methodName.slice(0,3)
    let newMethodName = 'show' + methodName.slice(3)    
    if(prefix === 'set' && typeof c[newMethodName] === 'function'){
      c[newMethodName]()
    }    
  })
  
  if(m.shroudIsVisible){
    v.shroud.styles('visibility: visible')('opacity: 1')
  }
  if(m.popupIsVisible){
    v.popupHolder.styles('visibility: visible')('opacity: 0.85')    
  }
  m.isOnline = navigator.onLine;
}

//======================================//
c.updateLocalStorage = function(){  
  if(localStorage){
    setTimeout(function(){
      let modelAsString=''
      try{
         modelAsString = JSON.stringify(m)        
      }
      catch(e){console.log(e)}

      localStorage.setItem('m', modelAsString)      
      console.log('\n\n\n')
      console.log(localStorage.getItem('m'))
    },100)
  }  
}

//==================================================//
c.downloadCurrentImage = function(){
  v.popupHolder
      .styles
        ('opacity: 0') 
        ('visibility: hidden')   
  m.popupIsVisible = false  
  if(m.source === v.btnYes){
    setTimeout(function(){
      document.location.assign(m.currentImageUrl)       
    }, 1)
  }
}

c.noIosWiggle = function(){
  if(m.moveCount > 1 && m.moved){
    m.eventObject.preventDefault()
  }
}
