MVC LIQUX:
Library
Initialize
Qualify
Update
eXtra