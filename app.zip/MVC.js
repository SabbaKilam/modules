/////////////////////////////////////////////////////////
// MVC LIQUX: Library, Initialize, Qualify, Update, eXtra

/* global L*/	// LIBRARY
let		m = {};	// MODEL
const	v = {};	// VIEW
const	c = {	  // CONTROLLER (_IQUX)
  ////////////////////////////////////////////////////
  ///////////////////| INITIALIZE |///////////////////
  ////////////////////////////////////////////////////
  async initialize(eventObject) {
    //one second heartbeat:
    //L.loopCall(()=>{console.log(`💗`)}, 1000)
    
  	/* Check if there is an initial populated model object from the server: */
  	const modelResponse = await window.fetch(`model.json`);
    let M = await modelResponse.json();
  	console.log( M );
  	
    c.initializeModel(eventObject);
    
    //give these two important objects their own ID's:
    window.id = `window`;
    window.document.id = `document`;
    
    //makes all ID-ed elements referable on v (example: v.testButton)
    L.attachAllElementsById(v);
    
    //for iOS mobile devices:
    L.noPinchZoom();

    //list all event types of interest for this app:
    const eventTypes = [
      //`wheel`,    // see seperate wheel event wiring below that prevents a warning
      //`click`,    // we have our own click test (m.clicked)
      //`dblclick`, // we have our own double click test (m.dblPressed)  
      `change`,
      `input`,
      `keydown`,   //maybe the preferred key event, with e.keyCode
      `keyup`,
      `keypress`, 
      `load`,
      `mousedown`,
      `mousemove`,
      `mouseout`,
      `mouseover`,
      `mouseup`,
      `offline`,
      `online`,
      `orientationchange`,
      `resize`,
      `touchend`,
      `touchmove`,
      `touchstart`,
      
       ////| music player event types: |/////
      'playing',
      'play',
      'pause',
      'volumechange',
      'timeupdate',
      'durationchange',
      'ended', //etc.      
    ];
    
    //Have the window object listen for every event type listed in the eventTypes array
    //and handle them with the same "handler supervisior", namely: c.qualifyHandlers
    eventTypes.forEach( eventType => window.addEventListener(eventType, c.qualifyHandlers, true) );
    window.addEventListener(`wheel`, c.qualifyHandlers, {passive: true} ) //prevents a warning
    
  },//====| END of main initialization |====//
  
  /////////////////////////////////////////////////////
  ///////////////////| QUALIFY |///////////////////////
  /////////////////////////////////////////////////////
  qualifyHandlers(eventObject){
    //first update the meta events like m.source and m.type
    //to make it easier to choose which handlers qualify to run
    c.updateMetaEvents(eventObject)
    
    //The propery names in the object below (handlerQualifiers) correspond to a handler method.
    //All booleans in the array must be true to qualify the corresponding handler to run 
    const handlerQualifiers = {
          setCircleColors:   [m.source.includedInClass(`circle`), m.clicked],
          setEditorTheme1:   [m.source === v.sliderGlass, m.released], 
          setEditorTheme:    [m.source === v.sliderGlass, m.clicked],      
          /*setEditorTheme:    [m.source === v.slider, m.clicked], */     
          setWheel:          [m.source === v.body, m.type === `wheel` ],      
          setButtonClicked:  [m.source === v.testButton, m.clicked],
          setDoublePressed:  [m.source === v.body, m.dblPressed],      
          showEvents:        [], //find helper functions like this in the eXtra section, way below   

          /*
          setXXZ: [m.source === null, m.type === ``],
          setXYX: [m.source === null, m.type === ``],
          setXYY: [m.source === null, m.type === ``],
          */
    };
    L.runQualifiedHandlers(handlerQualifiers, m, v, c);
  },  
  /////////////////////////////////////////////////////
  ///////////////////| UPDATE |////////////////////////
  /////////////////////////////////////////////////////
  setCircleColors(m){},
  showCircleColors(v){
    c.setAndShow(`doublePressed`) 
  },
  /////////////////////////////////////////////////////
  setEditorTheme1(m){},
  showEditorTheme1(v){
    const diff = m.clientX - m.startCoordinates[0] 
    let direction =   diff > 0 ?
                      `right`
                    : diff < 0 ?
                      `left`
                    : `none` 
    //v.info.innerText = `${direction}, delta = ${diff}`    
    if ( direction === `none` ){return}
    if ( (direction === `right` && m.dayTheme) || (direction === `left` && !m.dayTheme) ){
      c.setAndShow(`EditorTheme`)
    }
  },
  ////////////
  setEditorTheme(m){
    if(m.busyChangingThemes){return}    
    m.dayTheme = !m.dayTheme    
  },
  showEditorTheme(v){  
    if(m.busyChangingThemes){return} 
    m.busyChangingThemes = true
    L.loopCall.stop()     
    if(m.dayTheme){
      moveLeft(50) 
    }
    else{
      moveRight(50)     
    }
    ///////
    function moveLeft(pct){
      L.loopCall.stop()       
      let x = pct
      L.loopCall(function(){
        x -= 2
        v.slider.css(`left: ${x}%; right: auto`)
        if(x <= 0){
          v.slider.css(`left: 0;`)
          v.body.css(`background-image: linear-gradient(-20deg, transparent, #dedede, white); color: black`) 
          m.busyChangingThemes = false
          L.loopCall.stop()       
        }
      },1)    
    }
    ////////////
    function moveRight(pct){
      L.loopCall.stop()       
      let x = pct
      v.slider.css(`right: auto`)
      L.loopCall(function(){
        x -= 2
        v.slider.css(`right: ${x}%; left: auto`)
        if(x <= 0){
          v.slider.css(`right: 0;`)
          v.body.css(`background-image: linear-gradient(-20deg, transparent, #dedede, black); color: white`) 
          m.busyChangingThemes = false
          L.loopCall.stop()
        }
      },1)     
    }
  },
  //////////////////////////////////
  
  setButtonClicked(m){},
  showButtonClicked(v){
    const delay = m.timeBetweenEvents / 1000
    console.log(`time btween click events: ${delay} seconds`)
    v.delaySpan.innerText = `${delay} seconds`
    c.saveModel(m);
  },
  //////
  setDoublePressed(m){},
  showDoublePressed(v){
    
    //one second delay between double presses
    if(m.inDblPress){return}
    m.inDblPress = true
    setTimeout(()=>{m.inDblPress = false}, m.dblPressDelay)
    
    const randomColor = Math.floor( 360 * Math.random() );
    v.body.css(`background-color: hsla(${randomColor}, 50%, 50%, 0.95)`)
    console.log( `Double Pressed: ${randomColor}` )
    c.showButtonClicked(v)
  },
  /////////////
  setWheel(m){},
  showWheel(v){
    console.log(L.wheelDelta(m.eventObject))
    c.setAndShow(`DoublePressed`) 
  },

  //////////////////////////////////////////////////////
  ////////////////////| eXTRA |/////////////////////////
  //////////////////////////////////////////////////////  
  saveModel(m){

    m.timeBetweenModelSaves = Date.now() - m.timeOfModelSave    
    if(m.timeBetweenModelSaves < m.modelSaveDelay){return}
    
    m.timeOfModelSave = Date.now()
    //console.log(`Time between model saves: ${m.timeBetweenModelSaves/1000} seconds`)
    
    const modelSaver = new XMLHttpRequest()
    modelSaver.open(`POST`, `saveModel.php`)
    modelSaver.setRequestHeader(`FILENAME`,`model.json`)
    const MODEL = JSON.stringify(m);
    modelSaver.send( MODEL )
    console.log( `saving model:` )    
    console.log( m.historySource )
    
    /////
    modelSaver.onload = function(){
      if(modelSaver.status !== 200){
        console.log('Trouble saving model')
      }
      else {
      	console.log(`server says:`)
        console.log(modelSaver.responseText)      	
      }
    }
    /////
    modelSaver.onerror = function(){
      console.log('Trouble connecting to server when saving model')
      console.log(modelSaver.responseText)      
    }
  },
  /////////////////////////////////////
  showEvents(){
    if(m.historyType[0] === (`mousemove`||`touchmove`) && m.historyType[1] === (`mousemove`||`touchmove`)){
      m.moveCount += 1
    }
    else if(m.historyType[0] === (`mousemove`||`touchmove`)){
      m.moveCount = 1
    }
    else{
       m.moveCount = 0    
    }
    const source = m.id
      ? `Source = ${m.id}, `
      : ``
    console.log(`${source}move count = ${m.moveCount}`)
    console.log(`event = ${m.type}`)
    console.log(`====================================`)
  
  },
  /////////////////////////////
  setAndShow(suffix, namespace = this){
    if(typeof suffix !== `string`){
      c.log(`For c.setAndShow(suffix), suffix needs to be a string.`);
      return;
    }
    //set the first letter of suffix to uppercase
    suffix = suffix.charAt(0).toUpperCase() + suffix.slice(1);
    const setFuntionName =    `set${suffix}`;
    const showFunctionName =  `show${suffix}`;
    namespace[setFuntionName](m);
    namespace[showFunctionName](v);
  },
}//======| END of CONTROLLER |=======//
//////////////////////////////////////////////////////////////////
