<?php
    $contents = file_get_contents("php://input");
    $filename = "contacts.txt";
    file_put_contents($filename, $contents);
    exit("ok");  
?>