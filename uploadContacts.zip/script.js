/*global localStorage*/
const m = {}
const v = {}
const c = {}
//----------------------//
//["last","first","phone","email"]
m.contacts = [
 ["Philmore","Mitchell","215-520-1775","17Philmo6088@pit.edu"],
 ["Abdulmalik","Abbas","610-357-2710","aabdulmalik@pit.edu"]
]
//----------------------//
c.initialize = function(eventObject){
    //setTimeout(c.getServerContacts, 5000)
    c.getServerContacts()
}
//------| a bunch methods |------//
c.showLastContact = function(){
    const lastPosition = m.contacts.length - 1
    console.log(m.contacts[lastPosition])
}

c.showAllContacts = function(){
    console.log(m.contacts)
}

c.saveToServer = function(){
    const stringifiedContacts = JSON.stringify(m.contacts)
    const contactSaver = new XMLHttpRequest()
    contactSaver.open("POST", "saveContacts.php")
    contactSaver.send(stringifiedContacts)
    //-----------------------//
    contactSaver.onload = function(){
        if(contactSaver.status === 200){
            if(contactSaver.response === "ok"){
                c.saveLocally(stringifiedContacts)
            }
        }
        else{
            console.log("Trouble Saving File to server.")
        }
    }
    contactSaver.onerror = function(){
        console.log("Trouble Connecting to the server.")
    }
}

c.saveLocally = function(stringifiedContacts){
    localStorage.setItem("contacts", stringifiedContacts)
}

c.getLocalContacts = function(){
    const localContacts = localStorage.getItem(`contacts`)
    if(localContacts){
        m.contacts = JSON.parse(localContacts)
    }
    else{
        console.log("Can't find contact list: using default list.")
    }
}

c.getServerContacts = function(){
    const errorMessage = "Trouble getting contact list from server."
    const listGetter = new XMLHttpRequest()
    const path = `https://stored-contacts-sabbakilam1.c9users.io/contacts.txt?foobar=${Date.now()}`
    listGetter.open("GET", path)
    listGetter.send()
    //-------------------//
    listGetter.onload = function(){
        if(listGetter.status === 200){
            m.contacts = JSON.parse(listGetter.response)
            c.saveLocally(listGetter.response)
        }
        else{
            console.log(errorMessage)
            //get local contact list
            c.getLocalContacts()
        }
    }
    listGetter.onerror = function(){
            console.log(errorMessage)
            //get local contact list
            c.getLocalContacts()            
    }
}

c.addContact = function(contactStringArray){
    m.contacts.push(contactStringArray)
    c.showAndSave()
}

c.deleteContact = function(position){
    m.contacts.splice(position, 1)
    c.showAndSave()
}

c.showAndSave = function(){
    c.showLastContact()
    c.saveToServer()
}